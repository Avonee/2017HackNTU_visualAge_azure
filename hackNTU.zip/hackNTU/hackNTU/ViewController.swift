//
//  ViewController.swift
//  hackNTU
//
//  Created by Ya Fang Cheng on 2017/7/21.
//  Copyright © 2017年 Ya Fang Cheng. All rights reserved.
//

import UIKit
import MobileCoreServices
import Alamofire
import Firebase


class ViewController: UIViewController, UIScrollViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
  
    
    @IBOutlet weak var labelShow: UILabel!
    @IBOutlet weak var sex: UISegmentedControl!
    
    
    @IBOutlet weak var BigHead: UIImageView!
    var imagePicker:UIImagePickerController!
    
    var ref: DatabaseReference!
    var picNumber = 0
    override func viewDidLoad() {
        super.viewDidLoad()
      // postToAzure()
    }
    
    var whitchtype = 0
    @IBAction func getPictureClick(_ sender: Any) {
        whitchtype = 0
        imagePicker = UIImagePickerController()
        imagePicker.modalPresentationStyle = .currentContext
        
        imagePicker.sourceType = .photoLibrary
        
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func takePictureClick(_ sender: Any) {
        
        whitchtype = 1
        imagePicker = UIImagePickerController()
        imagePicker.modalTransitionStyle = .flipHorizontal
        imagePicker.allowsEditing = true//是否允许编辑
        imagePicker.sourceType = .camera//数据来源为摄像头
        imagePicker.videoMaximumDuration = 15      //模式录制视频长度,单位秒
        imagePicker.mediaTypes = ["public.image"]        //允许的相机类型(拍照,摄像....)
        imagePicker.videoQuality = .typeHigh    //视频质量
        imagePicker.cameraCaptureMode = .photo//初始摄像头的模式
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
        
        
    }
    
    
    //拿相片頁面
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if whitchtype == 0{
            if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
                BigHead.image = image
                
                
            }
            imagePicker.dismiss(animated: true, completion: nil)
        }else{
            //获取媒体的类型
            let mediaType = info[UIImagePickerControllerMediaType] as! String
            
            //如果媒体是照片
            if mediaType == kUTTypeImage as String {
                //获取到拍摄的照片, UIImagePickerControllerEditedImage是经过剪裁过的照片,UIImagePickerControllerOriginalImage是原始的照片
                let image = info[UIImagePickerControllerEditedImage] as! UIImage
                BigHead.image = image
                //调用方法保存到图像库中
                UIImageWriteToSavedPhotosAlbum(image, self,#selector(ViewController.image(image:didFinishSavingWithError:contextInfo:)), nil)
                
                
                
            }
            
            
            imagePicker.dismiss(animated: true, completion: nil)
        }
        
    }
    
    
    
    func image(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo:UnsafeRawPointer) {
        if error == nil {
            let ac = UIAlertController(title: "Saved!", message: "成功保存照片到图库", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(ac, animated: true, completion: nil)
        } else {
            let ac = UIAlertController(title: "Save error", message: error?.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(ac, animated: true, completion: nil)
        }
    }
    
    
    
    @IBAction func changeToURL(_ sender: Any) {
        
        //先測試firebase內有幾個 就+1開始
      // howManyFirebaseDataAre()
        
        
       
            
           self.post(image: self.BigHead.image!, for: "avon")
           // picNumber += 1
            
        
        
        
    }
    
    //MARK: post get firebase
    func howManyFirebaseDataAre(){
        Database.database().reference().observe(.childAdded, with: {(snapshot) in
            if snapshot.value != nil{
                print(snapshot.childrenCount)
                self.picNumber = Int(snapshot.childrenCount)
               
                
                
                
            }
            
        })
        
        
    }
    
    
    //要先把圖片變成url
     func post(image: UIImage, for username: String) {
        
        let imageData = UIImageJPEGRepresentation(image, 1)
            //UIImagePNGRepresentation(image)
        let base64Image = imageData?.base64EncodedString(options: .lineLength64Characters)
        
        let url = "https://api.imgur.com/3/upload"
        
        let parameters = [
            "image": base64Image
        ]
        
        Alamofire.upload(multipartFormData: { multipartFormData in
            if let imageData = UIImageJPEGRepresentation(image, 1) {
                multipartFormData.append(imageData, withName: username, fileName: "\(username).jpg", mimeType: "image/jpg")
            }
            
            for (key, value) in parameters {
                multipartFormData.append((value?.data(using: .utf8))!, withName: key)
            }}, to: url, method: .post, headers: ["Authorization": "Client-ID " + "5867856c9027819"],
                
                //Constants.IMGUR_CLIENT_ID],
                encodingCompletion: { encodingResult in
                    switch encodingResult {
                    case .success(let upload, _, _):
                        upload.response { response in
                            //This is what you have been missing
                            let json = try? JSONSerialization.jsonObject(with: response.data!, options: .allowFragments) as! [String:Any]
                            print(json ?? "")
                            let imageDic = json?["data"] as? [String:Any]
                            print(imageDic?["link"] ?? "")
                            self.postToAzure(imageurl: imageDic?["link"] as! String)
                        }
                    case .failure(let encodingError):
                        print("error:\(encodingError)")
                    }
        })
        
    }
    
    //再串azure的api
    
    func postToAzure(imageurl:String){
        
        
        let request = NSMutableURLRequest(url: NSURL(string: "https://westus.api.cognitive.microsoft.com/face/v1.0/detect?returnFaceId=true&returnFaceLandmarks=false&returnFaceAttributes=age,emotion")! as URL)
        
        let session = URLSession.shared
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("ec308fa44dec482d93f89d71c26aab8f", forHTTPHeaderField: "Ocp-Apim-Subscription-Key")
        
        let params:[String : String] =
            [
                "url": imageurl,
                //"https://scontent-tpe1-1.xx.fbcdn.net/v/t1.0-9/18698034_1711845338830991_8935035273656962076_n.jpg?oh=126bb146d5f9187309bd0786bf08ac83&oe=59F10288",
                
                
        ]
        
        print("params是\(params)")
        
        request.httpBody = try! JSONSerialization.data(withJSONObject: params, options: [])
        
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            guard data != nil else {
                print("no data found: \(String(describing: error))")
                return
            }
            
            
            
            do {
                if let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary {
                    _ = json.object(forKey: "token") as? String
                   
                    
                    
                } else {
                    let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)    // No error thrown, but not NSDictionary
                    print("Error could not parse JSON: \(String(describing: jsonStr))")
                    let json = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                    let faceAttributes = (json[0] as AnyObject).object(forKey: "faceAttributes")
                    let ageGet = (faceAttributes as AnyObject).object(forKey: "age")//數字
                    let emotionGet = (faceAttributes as AnyObject).object(forKey: "emotion")
                    
                    let a  = (emotionGet as AnyObject).object(forKey: "happiness")
                    
                    
                    print("ageGet拿到的是\(faceAttributes); 年齡是\(ageGet); 情緒是\(emotionGet); happiness是\(a)")
                    let b = a as! Float
                    DispatchQueue.main.async(execute: {
                        self.labelShow.text = "你的年齡是\(ageGet!), 覺得有\(b*100)%的開心 :)"
                        
                        //firebase
                        //let p = self.picNumber+1
                       // Database.database().reference().child("\(self.picNumber)").setValue(["headImage": imageurl,"age&feel": ["\(ageGet!)", "\(b*100)"],
                          //  "all":"你的年齡是\(ageGet!), 覺得有\(b*100)%的開心 :)"])
                        
                        //let key = self.ref.childByAutoId().key
                        let key = Database.database().reference().childByAutoId().key
                        
                        let post = ["headImage": imageurl,
                                    "age&feel": ["\(ageGet!)", "\(b*100)"],
                            "all":"你的年齡是\(ageGet!), 覺得有\(b*100)%的開心 :)", "vote":0] as [String : Any]
                        let childUpdates = ["\(key)": post]
                        
                        Database.database().reference().updateChildValues(childUpdates)
                        
                        //
                    })
                    
                    
                    /*
                    //firebase
                    
                    let key = self.ref.childByAutoId().key
                    let post = ["headImage": imageurl,
                                "age&feel": "\(ageGet!)\(b*100)" ,
                                "all":"你的年齡是\(ageGet!), 覺得有\(b*100)%的開心 :)"]
                    let childUpdates = ["\(key)": post]
                    
                    self.ref.updateChildValues(childUpdates)
                     */
                    //
                }
            } catch let parseError {
                print(parseError)                                                          // Log the error thrown by `JSONObjectWithData`
                let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print("Error could not parse JSON: '\(String(describing: jsonStr))'")
            }
        }
        
        task.resume()
    }
  



}




